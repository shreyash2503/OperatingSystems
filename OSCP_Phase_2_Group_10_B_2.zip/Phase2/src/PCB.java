public class PCB {
    String jOBID;
    int TTL;
    int TLL;
    int TTC;
    int LLC;

    public PCB(String jOBID, int TTL, int TLL, int TTC, int LLC){
        this.jOBID = jOBID;
        this.TTL = TTL;
        this.TLL = TLL;
        this.TTC = TTC;
        this.LLC = LLC;
    }
}
